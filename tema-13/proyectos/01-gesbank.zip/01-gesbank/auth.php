<?php
define("SMTP_USER", "diegogonzalezromero7@gmail.com");
define("SMTP_PASS", "yldg vnoj vqjk pfkk");
?>