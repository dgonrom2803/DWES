<?php 

// Cargo la vista
include "views/index.html";



?>