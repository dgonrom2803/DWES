<?php 

// Cargo el modelo
include 'models/modelCalcular.php';

// Cargo la vista
include "views/resultado.php";



?>