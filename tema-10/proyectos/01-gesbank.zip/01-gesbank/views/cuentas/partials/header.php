<header class="pb-3 mb-4 border-bottom">
    <div class="container">
        <h4 class="display-7">Tabla Cuentas </h4>
        <p class="lead">Proyecto 10.1 - PHP y MYSQL</p>
    </div>
</header>